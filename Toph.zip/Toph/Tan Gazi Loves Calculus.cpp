#include<bits/stdc++.h>
using namespace std;
char s[10009];
char a[10009], b[10009];
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
     cin >> s;

    int k, i, q;
    for(i=0; s[i]!='\0'; i++)
    {
        if(s[i] == 'x') break;
    }
    k = i;
    for(i=0; i<k; i++){ a[i] = s[i];} a[i] = '\0';
    int m;
    for(i=0; s[i]!= '\0'; i++)
    {
        bool res = false;
        if(s[i] == '+') {
            m = i+1;
            for(int j=m; s[j]!='\0'; j++)
            if(s[j] == 'x'){q=j;res = true; break;}
        }
        if(res) break;
    }
    int j=0;
    for(int i=m; i<q; i++) {b[j] = s[i]; j++;}b[j]='\0';
    string s1;
    s1 = a;
    ///cout << s1 << endl;
    stringstream geek(s1);
    int x;
    geek >> x;
    cout << x*2 << "x+" << b ;
    return 0;
}
