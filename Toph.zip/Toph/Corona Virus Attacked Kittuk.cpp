
#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    string s;
    cin >> s;
    int ln = s.size();
    if(s[ln-1] == '0'){
        for(int i=0; i<ln-1; ++i) cout<<s[i];
        cout<<endl;
        cout << "Stay at Home" << endl;
    }
    else
    cout << "Stay at Home" << endl;
    return 0;
}

