#include<bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t; cin >> t;
    while(t--)
    {
        int n; cin >> n;
        string s1, s2; cin >> s1 >> s2;
        int l1=0, l2=0;
        for(int i = 0; i<n; i++) {
      if(s1[i]=='a' || s1[i]=='e' || s1[i]=='i' ||
         s1[i]=='o' || s1[i]=='u' || s1[i]=='A' ||
         s1[i]=='E' || s1[i]=='I' || s1[i]=='O' ||
         s1[i]=='U')
      {
         l1++;
      }
      if(s2[i]=='a' || s2[i]=='e' || s2[i]=='i' ||
         s2[i]=='o' || s2[i]=='u' || s2[i]=='A' ||
         s2[i]=='E' || s2[i]=='I' || s2[i]=='O' ||
         s2[i]=='U')
      {
         l2++;
      }

    }
    if(l1>l2)cout << "First String" << endl;
    else if(l1 < l2) cout << "Second String" << endl;
    else cout << "Equal" << endl;
    }
    return 0;
}
