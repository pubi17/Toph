#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef tuple<int,int,int> T;
#define gcd(a,b) __gcd((a),(b))
#define lcm(a,b) ((a)*(b))/gcd((a),(b))
ll inf=1e18+42;
const double eps = 1e-8;
#define M_PI 3.14159265358979323846
const int M = 1e9+7;
const int MN = 1e9;
int main()
{
    ///freopen("input.txt", "r", stdin);
    ///freopen("output.txt", "w", stdout);
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    cout << fixed << setprecision(10);
    ll n, q; cin >> n >> q;
    vector<ll>v(n); for(ll i=0; i<n; ++i) cin >> v[i];

    ///for(int i=1; i<n; ++i) v[i] += v[i-1];

    while(q--)
    {
        ll a, l, r, g; cin >> a;
        cin >> l >> r;
        if(a==2){
            cin >> g;
            for(ll i=l-1; i<=r-1; ++i) v[i] /= (gcd(v[i],g));

        }
        else{
                ll sum = accumulate(v.begin()+(l-1), v.begin()+r, 0LL);
                cout << sum << endl;
                /*
      if(l-1==0) cout<<v[r-1]<<endl;
      else {
     ll sum = v[r-1]-v[l-2];
    ///for(int i=l-1; i<=r-1; ++i) sum += v[i];
    cout << sum << endl;
    }
    */
    }
    }

    return 0;
}
