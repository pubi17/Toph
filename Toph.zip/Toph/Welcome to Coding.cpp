
#include<bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    cout << "\"";
    cout <<"Welcome to Coding";
    cout << "\"";
    return 0;
}
