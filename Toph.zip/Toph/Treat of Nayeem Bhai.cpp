#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t; cin >> t;
    while(t--)
    {
        ll n; cin >> n;
        ll sum = 0;

        sum = (n*(n+1)*((n*n)+n+2))/8;

        cout << sum << endl;
    }

    return 0;
}
