#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,x,d,a[105];
int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>n>>x>>d;
    for(ll i=1;i<=n;i++)cin>>a[i];
    vector<ll> v;
    for(ll i=1;i<=n;i++){
        ll cur=0;
        for(auto &ele:v)ele=max(ele-d,0ll),cur+=ele;
        v.push_back(a[i]);
        cur+=a[i];
        if(cur>=x)return cout<<i , 0;
    }
}
