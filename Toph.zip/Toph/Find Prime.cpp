
#include <bits/stdc++.h>
using namespace std;

int main(){

	bool sieve[1000+1];

	memset(sieve,true,sizeof(sieve));
	sieve[0]=sieve[1]=false;
	for(int i=2;i*i<=1000;i++)
		if(sieve[i])
	for(int j=i*2;j<=1000;j+=i)
		sieve[j]=false;
int t; cin >> t;
while(t--){
	int k;
	cin>>k;
for(int i=k-1; i>=2; i--)
{
    if(sieve[i]){cout<<i<<" "; break;}
}
for(int i=k+1; i<=1000; i++)
{
    if(sieve[i]){cout<<i<<endl;break;}
}
}
	return 0;
}
