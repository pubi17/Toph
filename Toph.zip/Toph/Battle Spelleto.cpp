#include<bits/stdc++.h>
using namespace std;

bool cmp(pair<int,int>a, pair<int,int>b)
{
    return a.first < b.first;
}
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t; cin >> t;
    while(t--)
    {
        int n; cin >> n;
        pair<int, int>p[n];
        for(int i=0; i<n; i++)
        {
            int x; cin >> x;
            p[i].first = x;
            p[i].second = i+1;
        }

        sort(p, p+n, cmp);
       /// for(int i=0; i<n; i++) cout << p[i].first <<" "<<p[i].second << endl;
       ///cout << p[0].second << endl;
       for(int i=0; i<n; i++)
       {
           if(p[n-1].first == p[i].first) cout << p[i].second << endl;
       }
    }


    return 0;
}
