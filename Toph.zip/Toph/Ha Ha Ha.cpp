
#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t; cin >> t;
    for(int j=1; j<=t; j++){
            cout <<"Case "<<j<<": ";
    int ab, ac ; cin >> ab >> ac;

    cout << (ab*ab) + (ac*ac) << endl;
    }
    return 0;
}

