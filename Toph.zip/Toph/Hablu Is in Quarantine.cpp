
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    ll n,i,x,a,j; cin >> n;

    ll sz = n*n;

    char arr[sz+1];

    for(i=1; i<=sz; ++i) cin >>arr[i];

    cin >> x;
    pair <int, char>p[x];

    for(i=0; i<x; ++i)
    {
        cin >> a;
        p[i].first = a;
        p[i].second = arr[a];
    }
   /// for(i=0; i<x; ++i) cout<<p[i].first<< " " <<p[i].second<<endl;

    for(i=0; i<x; ++i)
    {
        if(p[i].second == 'c'){
                cout<<"YES"<<endl;
                j=i+1;
                while(j<x){
                    if(p[j].second == 'a') cout<< p[j].first << " ";
                 j++;

                }
        }
        if(j==x) break;
    }
    if(i == x) cout<<"NO"<<endl;

    return 0;
}

