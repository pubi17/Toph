
#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t;
    cin >> t;
    for(int j=1; j<=t; ++j)
    {
        int n,i,c=0;
        cin >> n;
        for(i=1; i<=n; ++i)
        {
            string s, s1;
            cin >> s;
            s1 =s;
            reverse(s.begin(), s.end());
            if(s == s1) c++;
        }
        cout<<"Operation "<<j<<": #"<<c<<endl;
    }
    return 0;
}
