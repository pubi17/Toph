#include<bits/stdc++.h>
using namespace std;
#ifndef M_PI
#    define M_PI 3.1415926535897932
#endif
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t;
    cin>>t;
    while(t--)
    {

        double AD,x, BD,AB,r;
        cin>>AD>>x;
        r=x*(M_PI/180);
        BD = AD / sin(r);

        AB = sqrt((BD*BD) - (AD*AD));

        cout<<fixed<<setprecision(6)<<AB + BD<<endl;

    }
    return 0;
}
