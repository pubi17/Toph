#include<iostream>
#include<bitset>
#include<string>
int cnt = 0;
typedef long long ll;
using namespace std;
void display( ll n, ll value)
{
    bitset<8>myBitset(value);
    bitset<8>myBitset1(n);
    if(myBitset1.to_string() == myBitset.to_string()) cnt ++;
    ///cout<<myBitset.to_string()<<endl;
}

int main()
{
    int t; cin >> t;
    while(t--)
    {

        ll n; cin >> n;
        for(ll i=0; i< n; ++i){
    ll valueA = n;
    ll valueB = i;

    display(n,valueA | valueB);
     valueA = i;
     valueB = n;

    display(n,valueA | valueB);

        }
       ll valueA = n;
     ll valueB = n;

    display(n,valueA | valueB);
        cout << cnt << endl;
        cnt = 0;
    }
    return 0;
}

