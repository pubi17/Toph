#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef tuple<int,int,int> T;
#define gcd(a,b) __gcd((a),(b))
#define lcm(a,b) ((a)*(b))/gcd((a),(b))
ll inf=1e18+42;
#define M_PI 3.14159265358979323846
const int M = 1e9+7;
const int MN = 1e9;

void solve()
{
    ll n; cin >> n;
    ll n1 = n;
    n *= 2;
    ll m = n;
    while(1)
    {
        if(!(n1&m)) {cout<<m<<endl; break;}
        else {n *=2; m=n;}
    }

}
int main()
{
    ///freopen("input.txt", "r", stdin);
    ///freopen("output.txt", "w", stdout);
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    cout << fixed << setprecision(10);
    int t; cin >> t;
    while(t--)
    {
        solve();
    }

    return 0;
}
