#include<bits/stdc++.h>
using namespace std;
typedef unsigned long long ll;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t; cin >> t;
    while(t--)
    {
        ll n, m,ans; cin >> n >> m;
        ll sum = 0;

        const unsigned int M = 1000000007;
        for(ll i=1; i<=n; ++i)
        {
            if (n%i == 0){
                    ///cout <<i%M << " " << m%M<< endl;
                    ans = pow(i%M,m%M);

            sum += (ans%M);
            }
        }
        cout << sum << endl;
    }

    return 0;
}
