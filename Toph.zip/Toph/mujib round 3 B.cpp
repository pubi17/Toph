
#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int n,res,m;
    cin >> n;
    while(1)
    {
        if(n&1)
        {
            res = n*3+1;
            if(n < res) {cout<<res<<endl; break;}
            else n = res;
        }

        else
        {
            if(n%4 == 0)
            {
                m=n/4;
                if(n>m){cout<<n<<endl; break;}
                else n = m;
            }
            else if(n%2 == 0)
            {
                m = n/2;
                if(n>m){cout<<n<<endl; break;}
                else n = m;
            }
        }
    }
    return 0;
}
