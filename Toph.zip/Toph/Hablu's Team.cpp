#include<bits/stdc++.h>
using namespace std;

long long dp[1000][1000];

int fib(int n,int r)
{
    if(r==1) return n;
    else if(n==r) return 1;
    else if(dp[n][r]!=-1) return dp[n][r];
    else{
        dp[n][r]=fib(n-1,r-1)+fib(n-1,r);
        return dp[n][r];
    }
}
int main()
{
    long long i,j,n,k;
    for(i=0;i<1000;i++)
   {
       for(j=0;j<1000;j++)
       {
           dp[i][j]=-1;
       }
   }
    cin>>n>>k;
   vector<long long>a(n);
   for(i=0; i<n; ++i) cin >> a[i];
   sort(a.begin(), a.end());
   long long c = 0;
   for(i=0; i<n; ++i){
    if(a[i]<k) c++;
   }
   if(c == 0) puts("0");
   else if(c > 0){
    int res= fib(c,2);
    cout<<res<<endl;
   }
}
