#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int n, x, sum = 0;
    cin >> n >> x;
    for(int i=1;i<=n; i++){int y; cin >> y; sum += y;}
    if(sum>x) cout<< "Yes" <<endl;
    else cout << "No" <<endl;

    return 0;
}

