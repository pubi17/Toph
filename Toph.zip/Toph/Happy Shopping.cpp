#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    ll n,m ; cin >> n >> m;
    vector<ll>p(n),h(n),mn(n),mx(n),v;

    for(ll i=0; i<n; ++i) cin >> p[i];
    for(ll i=0; i<n; ++i) cin >> h[i];
    for(ll i=0; i<n; ++i) cin >> mn[i];
    for(ll i=0; i<n; ++i) cin >> mx[i];

    ll sum1 = 0, sum2 = 0, ans1 = 0, ans2 = 0, s1=0;

    for(int i=0; i<n; ++i){
        sum1 += (mn[i]*p[i]);
        s1 += (mn[i]*h[i]);
        sum2 += (mx[i]*p[i]);
    }

    if(sum1>m )return cout<<"0"<<endl, 0;

    v.push_back(s1);
    s1 = 0;
   ll s = 0;
    while(1){

    for(int i=0; i<n; ++i) {
        if(mn[i]<mx[i]){
            s += (mn[i]++)*p[i];
            s1 += (mn[i])*h[i];
        }

    }
    if(s>m) break;
    else{
    v.push_back(s1);
    s = 0, s1 = 0;
    }
    }

   int k =*max_element(v.begin(), v.end());

    cout << k << endl;

    return 0;
}
