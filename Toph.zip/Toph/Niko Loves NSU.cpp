#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int n, i;
    vector<int>v(3);
    string s;
    cin >> n >> s;
    for(i=0; i<n; ++i)
    {
        if(s[i] == 'N') v[0]++;
        else if(s[i] == 'S') v[1]++;
        else if(s[i] == 'U') v[2]++;
    }
    int mini= *min_element(v.begin(),v.end());
    cout << mini <<endl;

    return 0;
}

