#include<bits/stdc++.h>
using namespace std;
typedef long long int ll;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t; cin >> t;
    while(t--)
    {
       ll a, b; cin >> a >> b;
       if(a%b==0 || b%a==0) cout << "true" << endl;
       else cout << "false" << endl;
    }

    return 0;
}
