#include<bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int n; cin >> n;
    string s; cin >> s;
    string C = "code";
    while(1)
    {
        i=0;
        for(int j=0; j<C.size(); ++j)
        {
            if(s[i] == C[j]){
                j++; i++;
                s.erase(s[i]);
            }
            else i++;
        }
        if(s.empty())break;

    }

    return 0;
}
