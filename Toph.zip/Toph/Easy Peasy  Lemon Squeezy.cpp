#include<bits/stdc++.h>
using namespace std;
vector<int>v1;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t; cin >> t;
    while(t--){
            int n,a,b,c,m,ans=0,ma,mi,beauty=0,sum = 0;
    cin >> n >> a >> b >> c >> m;

    while(n--)
    {
        ans = (a*b+c)%m;
        b = ans;

        if(ans&1) v1.push_back(ans);

        else if(!v1.empty())v1.pop_back();

        if (!v1.empty()){
            ma = *max_element(v1.begin(),v1.end());
            mi = *min_element(v1.begin(),v1.end());
            beauty = ma+mi;
        }

        else beauty=0;
        sum ^= beauty;
    }

    cout << sum << endl;
    }
    return 0;
}
